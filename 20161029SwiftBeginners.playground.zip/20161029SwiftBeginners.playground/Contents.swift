//: Playground - noun: a place where people can play

import UIKit

/* --------------------------------------------- 
 西磨翁『本気ではじめるiPhoneアプリ作り』
 ----------------------------------------------- */
var value: String?
value = "こんにちは"

print(value)           // Optional("こんにちは")

if let value = value { /** アンラップ処理 **/
    
    print(value)       // こんにちは
    
}

// 悪い例
if let unwrappedValue = value { /** アンラップ処理 **/
    
    print(unwrappedValue) // こんにちは
    
    // 別名をつけると間違った呼び出しで不具合が生じる
    print(value)          // Optional("こんにちは")
    
}
/* --------------------------------------------- */

if value != nil {
    // value! = someValue
}

if let value = value {
    // value = someValue
}

var canBeModified: Bool?
if let value = value,
    var canBeModified = canBeModified
    where canBeModified {
    // do something
}

var str: String = value ?? ""


class sampleClass {
    var str: String?
    func add1() -> Int? {
        if let str = str, let num = Int(str) {
            return num + 1
        } else {
            return nil
        }
    }
}
var a1: sampleClass? // nil
a1 = sampleClass()
a1?.str = "12"
a1?.add1()       // 13

//value + "！"

class OptionalChainingSample/*: CustomStringConvertible*/ {
    var value: String {
        get { return _value }
        set {
            print("setter called")
            _value = newValue
            print("setter finished")
        }
    }
    private var _value: String = "やあ"
    
    /*var description: String {
        return _value ?? ""
    }*/
}
var aSample: OptionalChainingSample?
print(aSample == nil)       // true
print(aSample?.value)       // nil
aSample?.value = "こんにちは" /* 何もprintされない
                               つまりsetが呼ばれていない */
print(aSample)              // nil
 
aSample = OptionalChainingSample()
print(aSample == nil)       // false
print(aSample?.value)       // Optional("やあ")
aSample?.value = "こんにちは" /* setter called
                               setter finished
                               がprintされる*/
print(aSample?.value)       // Optional("こんにちは")
print(aSample)              // Optional(OptionalChainingSample)

// Optional Chainingしなくてもよい
if let aSample = aSample {
    aSample.value = "お疲れさまです"
    print(aSample.value)    // お疲れさまです
}
print(aSample?.value)       // Optional("お疲れさまです")
print(aSample)              // Optional(OptionalChainingSample)